from django.urls import path
from . import views
urlpatterns = [
  
    path('', views.MainView.as_view(),name="main"),
    #Account Create
    path("Sign",views.User_Create.as_view(),name="SignUpForm"),
    # login Account
    path("log",views.UserLogin.as_view(),name="LoginForm"),
    # logout urls
    path("logout",views.User_logout.as_view(),name="Logout"),
    #add book url
    path("addbook",views.Add_Book.as_view(),name="addbook"),
    # update book data
    path("updatefinally<int:serial_no>/",views.UpdateBookFinally.as_view(),name="updatebook"),
    # Delete book data
    path("delete<int:serial_no>/",views.DeleteBook.as_view(),name="deletebook"),
    #Assign book add data
    path("Assignbook",views.AssignBook_View.as_view(),name="assignbook"),
    # api add data
    # path("take_image",views.TakenImage.as_view(),name="takeimage"),
    # student api add data
    path("assigsave",views.Save_Assign_Data.as_view(),name="Save_Assign_Data"),
    # student book details
    path("Assing_book",views.Assign_BookDetails.as_view(),name="Assign_book_data"),
    path('show<int:id>/',views.Student_data_delete.as_view(),name='delete_post'),

]
