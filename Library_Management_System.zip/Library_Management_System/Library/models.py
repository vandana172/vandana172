from django.db import models

# Create your models here.
class Library_Book(models.Model):
    serial_number=models.IntegerField(primary_key=True)
    book_name=models.CharField(max_length=300)
    book_image=models.ImageField(upload_to='images',null=True,blank=True,default='Not Available')
    # def __int__(self):
    #     return self.serial_number


class Student_Assigin_Book(models.Model):
    student_Id=models.IntegerField(primary_key=True)
    Student_Email_Id=models.EmailField(max_length=300)
    student_Mobail_No=models.BigIntegerField()
    student_name=models.CharField(max_length=300)
    BookSerial_No=models.CharField(max_length=600)
    AssignBook_Date=models.DateField(null=True,blank=True)
    admin_name=models.CharField(max_length=300)

class Student_Book(models.Model):
    student_Id=models.IntegerField(primary_key=True)
    Student_Email_Id=models.EmailField(max_length=300)
    student_Mobail_No=models.BigIntegerField()
    student_name=models.CharField(max_length=300)
    BookSerial_No=models.CharField(max_length=600)
    AssignBook_Date=models.DateField(null=True,blank=True)
    admin_name=models.CharField(max_length=300)

