from django import forms
from  . models import Library_Book,Student_Book
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField,UserChangeForm
from django.contrib.auth.models import User
class  SignUpForm(UserCreationForm):
        password1=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
        password2 = forms.CharField(label='Conform Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
        class Meta:
            model = User
            fields = ['username','first_name','last_name','email']
            labels={'username':'UserNmae','firstname':'FirstName','lastname':'LastName','email':'Email'}
            widgets = {'username':forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'})
            }

class LoginForm(AuthenticationForm):
    username = UsernameField(widget = forms.TextInput(attrs={'autofocus':True,'class':'form-control'}))
    password=forms.CharField(label='Password',strip=False,widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))

class AddBookForm(forms.ModelForm):
    """Form for the image model"""
    class Meta:
        model = Library_Book
        fields = ("serial_number","book_name","book_image")
        widgets = {
        'serial_number':forms.NumberInput(attrs={'class':'form-control' }),
        'book_name':forms.TextInput(attrs={'class':'form-control'}),
        'book_image':forms.FileInput(attrs={'class':'form-control'}),
        }

class Assigin_Book_Form(forms.ModelForm):
    """Form for the image model"""
    class Meta:
        model = Student_Book
        fields = ('student_Id','Student_Email_Id','student_Mobail_No','student_name','BookSerial_No','AssignBook_Date','admin_name')
        widgets = {
        'student_Id':forms.NumberInput(attrs={'class':'form-control' }),
        'Student_Email_Id':forms.EmailInput(attrs={'class':'form-control'}),
        'student_Mobail_No':forms.NumberInput(attrs={'class':'form-control'}),
        'student_name':forms.TextInput(attrs={'class':'form-control'}),
        'BookSerial_No':forms.TextInput(attrs={'class':'form-control'}),
        'AssignBook_Date':forms.DateInput(format='%d/%m/%Y',attrs={'class':'form-control'}),
        'admin_name':forms.NumberInput(attrs={'class':'form-control'}),

        }