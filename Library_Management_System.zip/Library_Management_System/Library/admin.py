from django.contrib import admin
from . models import Library_Book,Student_Book
# Register your models here.

@admin.register(Library_Book)
class Library_BookAdmin(admin.ModelAdmin):
    list_display=['serial_number','book_name','book_image']

@admin.register(Student_Book)
class Library_Student_Assigin_Book(admin.ModelAdmin):
    list_display=['student_Id','Student_Email_Id','student_Mobail_No','student_name','BookSerial_No','AssignBook_Date','admin_name']


